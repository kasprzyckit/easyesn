VERSION = (0, 1, 5, 5)

__version__ = '.'.join(map(str, VERSION))